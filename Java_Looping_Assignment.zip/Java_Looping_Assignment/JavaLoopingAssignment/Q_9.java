package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_9 {

	public static void main(String[] args) {
		  
		System.out.println("Enter Charector: ");
		Scanner sc= new Scanner(System.in);
		
		char ch = sc.next().charAt(0);
		
		if (ch >= 'A' && ch <= 'Z')
		{
			if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
			{
				System.out.println("Uppercased OVEL: " +ch);
			} else {
				System.out.println("Uppercased Consonent: " +ch);

			}
		} else if (ch >= 'a' && ch <= 'z') {
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
			{
				System.out.println("Lowercased OVEL: " +ch);
			}  else {
				System.out.println("Lowercased Consonent: " +ch);
			}
		} else {
			System.out.println("Not a charector " +ch);
		}
	}

}
