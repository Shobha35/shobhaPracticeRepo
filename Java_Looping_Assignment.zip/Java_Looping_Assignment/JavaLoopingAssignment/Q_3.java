package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_3 {

	public static void main(String[] args) {

		System.out.println("Enter the year: ");
		Scanner sc = new Scanner(System.in);
		
		int year = sc.nextInt();
		
		if (year % 400 == 0 || year % 4 == 0 && year % 100 != 0)
		{
			System.out.println("Year is leap year: " +year);
		} else {
			System.out.println("Year not leap year: " +year);
		}
		sc.close();
	}

}
