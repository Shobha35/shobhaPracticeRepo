package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_16 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number: ");
		
		int num = 0;
		int sum = 0;
		
		do{	
			num = sc.nextInt();
			
//			if (num<0)
//			{
//				break;
//			}
//			
			if (num % 2 == 0)
			{
				sum = sum + num;
			}
		}while(num >= 0);
		
		System.out.println("Sum of even numbers: " +sum);
		sc.close();

	}

}
