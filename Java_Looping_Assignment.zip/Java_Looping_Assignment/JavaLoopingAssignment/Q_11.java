package JavaLoopingAssignment;

public class Q_11 {

	public static void main(String[] args) {
		
		int num = 1;
		
		while( num <= 100) 
		{	
			if (num == 77)
			{
				break;
			}
			
			if (num % 3 == 0 && num % 5 == 0)
			{
				num++;
				continue;
			}
			
			System.out.println(num);
			num++;
		}

	}

}
