package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_7 {

	public static void main(String[] args) {
		
		System.out.println("Enter Math marks");
		Scanner sc1 = new Scanner(System.in);
		int math = sc1.nextInt();
		
		System.out.println("Enter Physics marks");
		Scanner sc2 = new Scanner(System.in);
		int physics = sc2.nextInt();
		
		System.out.println("Enter Chemistry marks");
		Scanner sc3 = new Scanner(System.in);
		int chemistry = sc3.nextInt();
		
		int total = math + physics + chemistry;
		
		if (math >= 60 && physics >= 50 && chemistry >= 40 && (total >= 180 || (math+physics) >= 120))
		{
			System.out.println("Eligible");
		} else {
			System.out.println(" Not Eligible");
		}
		
	}

}
