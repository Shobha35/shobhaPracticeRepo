package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_1 {
	
	public static void main(String[] args)
	{
		System.out.println("Enter a Number: ");
		Scanner sc = new Scanner(System.in);
		
		int num = sc.nextInt();
		
		if (num%3 == 0 && num%5 != 0 && num >= 50 && num <= 200)
		{
			System.out.println("VALID");
		} else {
			System.out.println("INVALID");
		}
		sc.close();
		
	}

}
