package JavaLoopingAssignment;

public class Q_22 {

	public static void main(String[] args) {
		
		int largest = 0;

        for (int num = 100; num <= 1000; num++) {

            int original = num;
            int reverse = 0;

            // reverse the number
            for (int temp = num; temp > 0; temp /= 10) {
                reverse = reverse * 10 + (temp % 10);
            }

            // check palindrome
            if (original == reverse && original > largest) {
                largest = original;
            }
        }

        System.out.println("Largest palindrome number: " + largest);

	}

}
