package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_19 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int choice;
		int a = 0, b=0;
		
		do 
		{
			System.out.println("\n-----MENU---------");
			System.out.println("1: Add");
			System.out.println("2: Subtract");
			System.out.println("3: Multiply");
			System.out.println("4: Exit");
			System.out.println("Enter your choice: ");
			choice = sc.nextInt();
			
			if (choice >= 1 && choice <= 3)
			{
				System.out.println("Enter first number: ");
				a = sc.nextInt();
				System.out.println("Enter second number: ");
				b = sc.nextInt();
				
			}
			
			switch(choice)
			{
				case 1: 
				System.out.println("Result: " + ( a + b ));
				break;
				
				case 2: 
					System.out.println("Result: " + ( a - b ));
					break;
					
				case 3: 
					System.out.println("Result: " + ( a * b ));
					break;
					
				case 4: 
					System.out.println("Exiting...... ");
					break;
					
					default:
						System.out.println("Invalid choice");
			}
			
			
		} while(choice != 4);
		sc.close();
	}

}
