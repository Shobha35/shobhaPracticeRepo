package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_13 {

	public static void main(String[] args) {
		
		System.out.println("Enter Number: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		
		int d = 0;
		int count = 0;
		
		while (num > 0)
		{
			d = num % 10;
			
			if (d == 2 || d == 3 || d == 5 || d == 7)
			{
				count++;
			}
			num = num / 10;
		}
		System.out.println("Count of prime digits in a number: "+count);

	}

}
