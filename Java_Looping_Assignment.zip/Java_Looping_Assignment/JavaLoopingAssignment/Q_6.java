package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_6 {

	public static void main(String[] args) {
		
		System.out.println("Enter a value: ");
		Scanner sc1 = new Scanner(System.in);
		int a = sc1.nextInt();
		
		System.out.println("Enter b value: ");
		Scanner sc2 = new Scanner(System.in);
		int b = sc2.nextInt();
		
		System.out.println("Enter c value: ");
		Scanner sc3 = new Scanner(System.in);
		int c = sc3.nextInt();
		
		System.out.println("Enter d value: ");
		Scanner sc4 = new Scanner(System.in);
		int d = sc4.nextInt();
		
		if (a>b) {
			if (a>c) {
				if (a>d) {
					System.out.println("a is largest");
				} else {
					System.out.println("d is largest");
				}
			} else {
				if (c>d) {
					System.out.println("c is largest");
				} else {
					System.out.println("d is largest");
				}
			}
		} else {
			if (b>c) {
				if (b>d) {
					System.out.println("b is largest");
				} else {
					System.out.println("d is largest");
				}
			} else {
				if (c>d) {
					System.out.println("c is largest");
				} else {
					System.out.println("d is largest");
				}
			}
		}
		
	}

}
