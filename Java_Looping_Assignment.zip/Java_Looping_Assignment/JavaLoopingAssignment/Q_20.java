package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_20 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int num = sc.nextInt();
		
		int temp = num;
		int div = 1;
		int firstDigit = 0;
		int lastDigit = 0;
		boolean isPalidrome = true;
		
		do {
			div = div * 10;
			temp = temp / 10;
		} while(temp != 0);
		
		div = div / 10;
		temp = num;
		
		do {
			firstDigit = temp / div;
			lastDigit = temp % 10;
			
			if (firstDigit != lastDigit)
			{
				isPalidrome = false;
				break;
			}
			
			temp = (temp % div) /10;
			div = div / 100;
			
				
		}while(div > 0);
		
		if (isPalidrome)
		{
			System.out.print("Number is Palindrome");
		} else {
			System.out.print("Number is not Palindrome");
		}
		
	}

}
