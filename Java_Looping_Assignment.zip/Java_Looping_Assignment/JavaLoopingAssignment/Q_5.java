package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_5 {

	public static void main(String[] args) {

		System.out.println("Enter the number: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		
		if (num % 2 == 0 && num % 3 == 0)
		{
			System.out.println("A");
		} else if (num % 3 == 0 && num % 2 != 0){
			System.out.println("B");
		} else if (num % 2 == 0 && num % 3 != 0) {
			System.out.println("C");
		} else {
			System.out.println("D");
		}
	}

}
