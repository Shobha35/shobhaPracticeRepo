package JavaLoopingAssignment;

public class Q_21 {

	public static void main(String[] args) {
		
		System.out.println("Numbers between 1 and 500 with exactly 3 divisors:");

        for (int i = 2; i * i <= 500; i++) {

            boolean isPrime = true;

            for (int j = 2; j <= i / 2; j++) {
                if (i % j == 0) {
                    isPrime = false;
                    break;
                }
            }

            if (isPrime) {
                System.out.println(i * i);
            }
        }
	}

}
