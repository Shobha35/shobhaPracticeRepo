package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = sc.nextInt();

        // Check 3-digit number
        if ((num >= 100 && num <= 999) || (num <= -100 && num >= -999)) {

            int n = Math.abs(num);   // handle negative numbers
            int sum = 0;

            sum = sum + (n % 10);
            n = n / 10;
            sum = sum + (n % 10);
            n = n / 10;
            sum = sum + n;

            // Nested if for even / odd
            if (sum % 2 == 0) {
                System.out.println("3-digit number and sum of digits is EVEN");
            } else {
                System.out.println("3-digit number and sum of digits is ODD");
            }

        } else {
            System.out.println("Not a 3-digit number");
        }

        sc.close();

	}

}
