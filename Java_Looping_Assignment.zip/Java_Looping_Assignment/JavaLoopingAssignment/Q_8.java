package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_8 {

	public static void main(String[] args) {
		
		System.out.println("Enter age: ");
		Scanner sc1 = new Scanner(System.in);
		int age = sc1.nextInt();
		
		System.out.println("Enter salary: ");
		Scanner sc2 = new Scanner(System.in);
		int salary = sc2.nextInt();
		
		if (age < 25)
		{
			System.out.println("Not Eligible");
		} else {
			if (salary < 30000)
			{
				System.out.println("Eligible for loan A");
			} else {
				if (age >= 30) {
					if(salary > 50000) {
						System.out.println("Eligible for loan B");
					} else {
						System.out.println("Not Eligible for loan B");
					}
				} else {
					System.out.println("Not Eligible");
				}
			}
		}
	}

}
