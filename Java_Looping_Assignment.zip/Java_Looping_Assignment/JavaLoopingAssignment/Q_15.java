package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_15 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter N terms: ");
		int n = sc.nextInt();
		
		int num = 1;
		int diff = 1;
		int count = 1;
		
		while (count <= n)
		{
			System.out.print(num + " ");
			num = num + diff;
			diff++;
			count++;
		}

	}

}
