package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_4 {

	public static void main(String[] args) {

		System.out.println("Enter the number: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		
		if (num > 0 && num % 4 == 0) {
		    System.out.println("Positive and divisible by 4");
		} else if (num < 0 && num % 6 == 0) {
		    System.out.println("Negative and divisible by 6");
		} else {
		    System.out.println("Does not satisfy any condition");
		}

	}

}
