package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_17 {

	public static void main(String[] args) {
		
		System.out.println("Enter a number: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		
		int temp = num;
		int div = 1;
		int digit = 0;
		
		do {
			div = div * 10;
			temp = temp/10;
		} while(temp != 0);
		
		div = div / 10;
		
		do {
			digit = num / div;
			System.out.print(digit+ " ");
			num = num % div;
			div = div / 10;
		} while(div != 0);
		sc.close();

	}

}
