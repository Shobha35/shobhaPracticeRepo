package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_12 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number: ");
		int num = sc.nextInt();
		int rev = 0;
		int d = 0;
		
		while (num >= 0)
		{
			d = num % 10;
			
			if (d == 0)
			{
				break;
			}
			
			rev = rev * 10 + d;
			num = num/10;
		}
		System.out.println("Reverse number (Stopped at 0): "+rev);
		
	}

}
