package JavaLoopingAssignment;

public class Q_18 {

	public static void main(String[] args) {
		
		int i = 10;
		do 
		{
			System.out.println("Loop executed");
		} while(i<5);
		
		 char[] str ={'A','B','C'} ;
	        System.out.println(str);
	}

}
