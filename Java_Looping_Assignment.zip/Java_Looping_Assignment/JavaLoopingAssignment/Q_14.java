package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_14 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of terms: ");
		
		int num = sc.nextInt();
		
		int n1 = 0;
		int n2 = 1;
		int n3 = 0;
		int count = 0;
		
		while (count <= num)
		{
			if (n1 > 500)
			{
				break;
			}
			System.out.print(n1 + " ");
			
			n3 = n1 + n2;
			n1 = n2;
			n2 = n3;
			count ++;
		}

	}

}
