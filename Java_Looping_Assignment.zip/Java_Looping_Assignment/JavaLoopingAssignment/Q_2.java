package JavaLoopingAssignment;

import java.util.Scanner;

public class Q_2 {

	public static void main(String[] args) {
		
		System.out.println("Enter a value: ");
		Scanner sc1 = new Scanner(System.in);
		int a = sc1.nextInt();
		
		System.out.println("Enter b value: ");
		Scanner sc2 = new Scanner(System.in);
		int b = sc2.nextInt();
		
		System.out.println("Enter c value: ");
		Scanner sc3 = new Scanner(System.in);
		int c = sc3.nextInt();
		
		if ((a>b && a<c) || (a>c && a<b))
		{
			System.out.println("a is second largest :" +a);
		} 
		else if ((b>a && b<c) || (b>c && b<a))
		{
			System.out.println("b is second largest: " +b);
			} else {
				System.out.println("c is second largest: " +c);
			}
		}

}
